import { defineConfig, configDefaults } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  test: {
    exclude: [...configDefaults.exclude, '**/backups/**'],
  },
  server: { port: 5173, proxy: { '/api': 'http://127.0.0.1:8787' } },
});
