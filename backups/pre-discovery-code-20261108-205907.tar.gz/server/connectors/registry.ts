import type { DiscoveryConnector } from '../discovery/types.ts';

const connectors = new Map<string, DiscoveryConnector>();

export function registerConnector(connector: DiscoveryConnector): void {
  const slug = connector.platformSlug.trim().toLowerCase();

  if (!slug) {
    throw new Error('Connector platform slug is required');
  }

  if (connectors.has(slug)) {
    throw new Error(`Connector already registered: ${slug}`);
  }

  connectors.set(slug, connector);
}

export function getConnector(slug: string): DiscoveryConnector | undefined {
  return connectors.get(slug.trim().toLowerCase());
}

export function listConnectors(): string[] {
  return [...connectors.keys()];
}

export function clearConnectors(): void {
  connectors.clear();
}
