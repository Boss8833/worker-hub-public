import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  get: vi.fn(),
  run: vi.fn(),
  discover: vi.fn(),
}));

vi.mock('../db.ts', () => ({
  get: mocks.get,
  run: mocks.run,
}));

vi.mock('../connectors/registry.ts', () => ({
  getConnector: () => ({
    platformSlug: 'taskmarket',
    discover: mocks.discover,
  }),
}));

import { discoverPlatform } from './engine.ts';

const platform = {
  id: 1,
  slug: 'taskmarket',
  base_url: '',
  enabled: 1,
  connector: 'taskmarket',
};

const settings = {
  min_reward: 5,
  filters_json: '{"include":[],"exclude":[]}',
};

const task = {
  externalId: 'external-1',
  title: 'Write a security report',
  description: 'Prepare a security report',
  requirements: '',
  reward: 10,
  currency: 'USDC',
  deadline: null,
  aiSuitability: null,
  eligibility: 'eligible' as const,
  eligibilityReasons: [],
  platformId: 1,
  platformSlug: 'taskmarket',
  discoveredAt: new Date().toISOString(),
};

describe('discovery eligibility', () => {
  beforeEach(() => {
    vi.clearAllMocks();

    mocks.get.mockImplementation((sql: string) => {
      if (sql.includes('FROM platforms')) return platform;
      if (sql.includes('FROM worker_settings')) return settings;
      if (sql.includes('FROM tasks')) return undefined;
      return undefined;
    });

    mocks.discover.mockResolvedValue([task]);
    mocks.run.mockReturnValue({ changes: 1 });
  });

  it('stores an eligible discovered task as eligible', async () => {
    const result = await discoverPlatform(1);

    expect(result.inserted).toBe(1);
    expect(mocks.run).toHaveBeenCalledOnce();

    const sql = mocks.run.mock.calls[0][0] as string;
    expect(sql).toContain("'eligible'");
    expect(sql).not.toContain("'discovered'");
  });

  it('does not insert an ineligible task', async () => {
    mocks.discover.mockResolvedValue([{
      ...task,
      eligibility: 'ineligible',
      eligibilityReasons: ['expired'],
    }]);

    const result = await discoverPlatform(1);

    expect(result.inserted).toBe(0);
    expect(result.skipped).toBe(1);
    expect(mocks.run).not.toHaveBeenCalled();
  });

  it('does not insert a duplicate task', async () => {
    mocks.get.mockImplementation((sql: string) => {
      if (sql.includes('FROM platforms')) return platform;
      if (sql.includes('FROM worker_settings')) return settings;
      if (sql.includes('FROM tasks')) return { id: 99 };
      return undefined;
    });

    const result = await discoverPlatform(1);

    expect(result.inserted).toBe(0);
    expect(result.skipped).toBe(1);
    expect(mocks.run).not.toHaveBeenCalled();
  });
});
