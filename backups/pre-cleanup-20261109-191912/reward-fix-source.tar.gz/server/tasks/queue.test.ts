import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { createRequire } from 'node:module';
import {
  claimNextTask,
  enqueueEligibleTasks,
  requeueRetryableTasks,
} from './queue.ts';

const { DatabaseSync } = createRequire(import.meta.url)(
  'node:sqlite',
) as typeof import('node:sqlite');

describe('task queue', () => {
  let database: InstanceType<typeof DatabaseSync>;

  beforeEach(() => {
    database = new DatabaseSync(':memory:');

    database.exec(`
      CREATE TABLE platforms (
        id INTEGER PRIMARY KEY,
        enabled INTEGER NOT NULL,
                              archived_at TEXT
      );

      CREATE TABLE worker_settings (
        id INTEGER PRIMARY KEY,
        automation_enabled INTEGER NOT NULL DEFAULT 1,
        min_reward REAL NOT NULL,
        max_concurrent INTEGER NOT NULL,
        platform_ids TEXT NOT NULL
      );

      CREATE TABLE tasks (
        id INTEGER PRIMARY KEY,
        platform_id INTEGER NOT NULL,
        external_id TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        requirements TEXT,
        reward REAL NOT NULL,
        currency TEXT NOT NULL,
        deadline TEXT,
        ai_suitability TEXT,
        is_mock INTEGER NOT NULL DEFAULT 0,
        status TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE task_executions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id INTEGER NOT NULL,
        state TEXT NOT NULL,
        attempt INTEGER NOT NULL DEFAULT 1,
        output TEXT,
        error TEXT,
        started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        finished_at TEXT
      );

      CREATE INDEX idx_exec_task ON task_executions(task_id);

      INSERT INTO platforms (id, enabled)
      VALUES (1, 1), (2, 1), (3, 0);

      INSERT INTO worker_settings
        (id, automation_enabled, min_reward, max_concurrent, platform_ids)
      VALUES (1, 1, 5, 1, '[1]');
    `);
  });

  afterEach(() => {
    database.close();
  });

  function addTask(
    id: number,
    platformId: number,
    status = 'eligible',
    reward = 10,
  ) {
    database
      .prepare(`
        INSERT INTO tasks (
          id, platform_id, external_id, title, description,
          requirements, reward, currency, status
        ) VALUES (?, ?, ?, ?, '', '', ?, 'USD', ?)
      `)
      .run(id, platformId, `external-${id}`, `Task ${id}`, reward, status);
  }

  function updateSettings(
    minReward: number,
    maxConcurrent: number,
    platformIds: number[],
  ) {
    database
      .prepare(`
        UPDATE worker_settings
        SET min_reward = ?, max_concurrent = ?, platform_ids = ?
        WHERE id = 1
      `)
      .run(minReward, maxConcurrent, JSON.stringify(platformIds));
  }

  it('queues only eligible tasks from selected enabled platforms', () => {
    addTask(1, 1, 'eligible', 10);
    addTask(2, 2, 'eligible', 10);
    addTask(3, 3, 'eligible', 10);
    addTask(4, 1, 'discovered', 10);
    addTask(5, 1, 'eligible', 3);

    expect(enqueueEligibleTasks(database)).toBe(1);

    const rows = database
      .prepare('SELECT id, status FROM tasks ORDER BY id')
      .all() as { id: number; status: string }[];

    expect(rows.map((row) => row.status)).toEqual([
      'queued',
      'eligible',
      'eligible',
      'discovered',
      'eligible',
    ]);
  });

  it('does not queue tasks from archived platforms', () => {
    addTask(10, 1, 'eligible', 10);
    database.prepare(
      "UPDATE platforms SET archived_at = CURRENT_TIMESTAMP WHERE id = 1",
    ).run();

    expect(enqueueEligibleTasks(database)).toBe(0);

    const row = database
      .prepare('SELECT status FROM tasks WHERE id = 10')
      .get() as { status: string };

    expect(row.status).toBe('eligible');
  });

  it('does not queue anything when no platform is selected', () => {
    updateSettings(0, 1, []);
    addTask(1, 1);

    expect(enqueueEligibleTasks(database)).toBe(0);
  });

  it('does not enqueue the same task twice', () => {
    addTask(1, 1);

    expect(enqueueEligibleTasks(database)).toBe(1);
    expect(enqueueEligibleTasks(database)).toBe(0);
  });

  it('claims the next queued task and changes its status', () => {
    addTask(1, 1);
    enqueueEligibleTasks(database);

    const task = claimNextTask(database);

    expect(task?.id).toBe(1);
    expect(task?.attempt).toBe(1);
    expect(task?.executionId).toBeGreaterThan(0);

    const row = database
      .prepare('SELECT status FROM tasks WHERE id = 1')
      .get() as { status: string };

    expect(row.status).toBe('executing');
  });

  it('creates an execution record atomically when claiming', () => {
    addTask(1, 1);
    enqueueEligibleTasks(database);

    const task = claimNextTask(database);

    const execution = database
      .prepare(`
        SELECT id, task_id, state, attempt
        FROM task_executions WHERE task_id = 1
      `)
      .get() as {
        id: number;
        task_id: number;
        state: string;
        attempt: number;
      };

    expect(execution).toEqual({
      id: task?.executionId,
      task_id: 1,
      state: 'executing',
      attempt: 1,
    });
  });

  it('does not claim when automation is disabled', () => {
    addTask(1, 1);
    enqueueEligibleTasks(database);

    database
      .prepare('UPDATE worker_settings SET automation_enabled = 0 WHERE id = 1')
      .run();

    expect(claimNextTask(database)).toBeNull();

    const row = database
      .prepare('SELECT status FROM tasks WHERE id = 1')
      .get() as { status: string };

    expect(row.status).toBe('queued');
  });

  it('does not claim when the concurrency limit is reached', () => {
    addTask(1, 1, 'executing');
    addTask(2, 1, 'queued');

    expect(claimNextTask(database)).toBeNull();
  });

  it('does not claim a task from a platform no longer selected', () => {
    addTask(1, 1, 'queued');
    updateSettings(0, 1, [2]);

    expect(claimNextTask(database)).toBeNull();
  });

  it('does not claim queued tasks from archived platforms', () => {
    addTask(10, 1, 'queued');
    database.prepare(
      "UPDATE platforms SET archived_at = CURRENT_TIMESTAMP WHERE id = 1",
    ).run();

    expect(claimNextTask(database)).toBeNull();

    const row = database
      .prepare('SELECT status FROM tasks WHERE id = 10')
      .get() as { status: string };

    expect(row.status).toBe('queued');

    const executions = database
      .prepare('SELECT COUNT(*) AS count FROM task_executions WHERE task_id = 10')
      .get() as { count: number };

    expect(executions.count).toBe(0);
  });

  it('does not claim a task below the current minimum reward', () => {
    addTask(1, 1, 'queued', 3);

    expect(claimNextTask(database)).toBeNull();
  });

  it('returns null when the queue is empty', () => {
    expect(claimNextTask(database)).toBeNull();
  });

  it('requeues a failed task when its latest execution error is retryable', () => {
    addTask(1, 1, 'failed');
    database.prepare(`
      INSERT INTO task_executions (task_id, state, attempt, error)
      VALUES (1, 'failed', 1, 'AI_UPSTREAM_FAILED:retryable')
    `).run();

    expect(requeueRetryableTasks(database)).toBe(1);

    const row = database
      .prepare('SELECT status FROM tasks WHERE id = 1')
      .get() as { status: string };
    expect(row.status).toBe('queued');
  });

  it('does not requeue failed tasks from archived platforms', () => {
    addTask(10, 1, 'failed');
    database.prepare(`
      INSERT INTO task_executions (task_id, state, attempt, error)
      VALUES (10, 'failed', 1, 'AI_UPSTREAM_FAILED:retryable')
    `).run();
    database.prepare(
      "UPDATE platforms SET archived_at = CURRENT_TIMESTAMP WHERE id = 1",
    ).run();

    expect(requeueRetryableTasks(database)).toBe(0);

    const row = database
      .prepare('SELECT status FROM tasks WHERE id = 10')
      .get() as { status: string };

    expect(row.status).toBe('failed');
  });

  it('does not requeue permanent or unclassified errors', () => {
    addTask(1, 1, 'failed');
    addTask(2, 1, 'failed');
    database.prepare(`
      INSERT INTO task_executions (task_id, state, attempt, error)
      VALUES
        (1, 'failed', 1, 'AI_AUTH_FAILED:permanent'),
        (2, 'failed', 1, 'EXECUTION_FAILED')
    `).run();

    expect(requeueRetryableTasks(database)).toBe(0);
  });

  it('does not requeue when the latest execution is not retryable', () => {
    addTask(1, 1, 'failed');
    database.prepare(`
      INSERT INTO task_executions (task_id, state, attempt, error)
      VALUES
        (1, 'failed', 1, 'AI_UPSTREAM_FAILED:retryable'),
        (1, 'failed', 2, 'AI_AUTH_FAILED:permanent')
    `).run();

    expect(requeueRetryableTasks(database)).toBe(0);
  });

  it('does not requeue tasks that already used three attempts', () => {
    addTask(1, 1, 'failed');
    database.prepare(`
      INSERT INTO task_executions (task_id, state, attempt, error)
      VALUES
        (1, 'failed', 1, 'AI_UPSTREAM_FAILED:retryable'),
        (1, 'failed', 2, 'AI_UPSTREAM_FAILED:retryable'),
        (1, 'failed', 3, 'AI_UPSTREAM_FAILED:retryable')
    `).run();

    expect(requeueRetryableTasks(database)).toBe(0);
  });

  it('does not requeue when automation is disabled', () => {
    addTask(1, 1, 'failed');
    database.prepare(`
      INSERT INTO task_executions (task_id, state, attempt, error)
      VALUES (1, 'failed', 1, 'AI_UPSTREAM_FAILED:retryable')
    `).run();
    database.prepare(
      'UPDATE worker_settings SET automation_enabled = 0 WHERE id = 1',
    ).run();

    expect(requeueRetryableTasks(database)).toBe(0);
  });

  it('does not requeue tasks from unselected or disabled platforms', () => {
    addTask(1, 2, 'failed');
    addTask(2, 3, 'failed');
    database.prepare(`
      INSERT INTO task_executions (task_id, state, attempt, error)
      VALUES
        (1, 'failed', 1, 'AI_UPSTREAM_FAILED:retryable'),
        (2, 'failed', 1, 'AI_UPSTREAM_FAILED:retryable')
    `).run();

    expect(requeueRetryableTasks(database)).toBe(0);
  });

  it('increments the attempt number when a failed task is retried', () => {
    addTask(1, 1);
    enqueueEligibleTasks(database);

    const first = claimNextTask(database);
    expect(first?.attempt).toBe(1);

    database
      .prepare("UPDATE task_executions SET state = 'failed' WHERE id = ?")
      .run(first!.executionId);

    database
      .prepare("UPDATE tasks SET status = 'queued' WHERE id = 1")
      .run();

    const second = claimNextTask(database);

    expect(second?.id).toBe(1);
    expect(second?.attempt).toBe(2);
  });

  it('does not claim a task after three execution attempts', () => {
    addTask(1, 1, 'queued');

    database
      .prepare(`
        INSERT INTO task_executions (task_id, state, attempt)
        VALUES (1, 'failed', 1), (1, 'failed', 2), (1, 'failed', 3)
      `)
      .run();

    expect(claimNextTask(database)).toBeNull();
  });
});
